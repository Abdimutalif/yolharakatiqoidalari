package com.uz.yolharakatiqoidalari.utils

object Constant {
    const val  DB_NAME="road_sign"
    const val  DB_VERSION=1

    const val TABLE_ZNAK_NAME="znak_table"
    const val ZNAK_ID="znak_id"
    const val IMAGE_ZNAK="image"
    const val ZNAK_NAME="name_znak"
    const val ZNAK_INFO="info_znak"
    const val ZNAK_CATEGORY="znak_category"
    const val ZNAK_KATEGORY_POSITION="position_category"
    const val ZNAK_LEEK_BACKGRAUND1="leek"


    const val TABLE_ZNAKLEEK_NAME="znakleek_table"
    const val ZNAKLEEK_ID="znakleek_id"
    const val IMAGELEEK_ZNAK="imageleek"
    const val ZNAKLEEK_NAME="nameleek_znak"
    const val ZNAKLEEK_INFO="info_znakleek"
    const val ZNAKLEEK_CATEGORY="znakleek_category"
    const val ZNAKLEEK_KATEGORY_POSITION="position_categoryleek"
    const val ZNAK_LEEK_BACKGRAUND="backgraund"
}